/**
 * index
 */
define(function(require) {
    var $ = require('jquery');
    var base = require('base');
    var com = require('./common');
    //测试
    com.demo();






    
});
